import org.junit.jupiter.api.Test;

/**
 * Created: 17.01.2022
 *
 * @author Kilian Baier (20190608)
 */
public class TestTest {
    @Test
    public void meinTest(){

    }
}
