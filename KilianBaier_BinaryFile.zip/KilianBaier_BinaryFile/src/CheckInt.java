import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Created: 17.01.2022
 *
 * @author Kilian Baier (20190608)
 */
public class CheckInt {


    public static void createFile(String filename, double... values) throws IOException {
        try {
            if (!Files.exists(Path.of(filename))) {
                File newFilename = new File(filename);
                DataOutput writer = new DataOutputStream(new FileOutputStream(newFilename));
                writer.write(values.length);
                for(double value : values){
                    writer.writeDouble(value);
                }
            }
        }
        catch (IOException e){
            System.out.printf("IOException");
        }
    }

    public static boolean isValidFile(String filename) throws IOException{
        RandomAccessFile raf = new RandomAccessFile(filename, "rw");
        raf.seek(0);
        int intFromFile = raf.readInt();
        double var_double = raf.readDouble()*8;
        return intFromFile == var_double;
    }


    public static String getFileInfo(String filename) throws IOException{
        return "HALLO";
    }

    public static void append(String filename, double toAppend){

    }



    public static void main(String[] args) {
    }

}
