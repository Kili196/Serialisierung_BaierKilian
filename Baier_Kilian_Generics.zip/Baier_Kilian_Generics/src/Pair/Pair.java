package Pair;

/**
 * Created: 11.10.2021
 *
 * @author Kilian Baier (20190608)
 */
public class Pair<T>{
    private  T first;
    private  T second;
    private T temp;


    public Pair(T first, T second){
        this.first = first;
        this.second = second;
    }

    public T getFirst() {
        return first;
    }
    public T getSecond(){
        return second;
    }

    public  void flipping(){
        first = temp;
        second = first;
        temp = second;

    }


}
