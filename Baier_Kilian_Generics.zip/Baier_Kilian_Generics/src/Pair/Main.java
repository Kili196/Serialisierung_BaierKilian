package Pair;

/**
 * Created: 11.10.2021
 *
 * @author Kilian Baier (20190608)
 */
public class Main {
    public static void main(String[] args) {
        Pair<Integer, String> pair = new Pair<>(3, "if");
        Pair<String, Integer> flipped = pair.flipped();
        flipped.getSecond() == pair.getFirst(); //true
    }
}
