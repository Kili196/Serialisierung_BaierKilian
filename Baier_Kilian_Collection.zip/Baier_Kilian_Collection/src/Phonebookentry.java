import java.util.Objects;

/**
 * Created: 18.10.2021
 *
 * @author Kilian Baier (20190608)
 */
public  class  Phonebookentry {
    private  String  number;
    private  String  name;
    private String tmp;
    private boolean TrueorFale;


    public Phonebookentry(String number) {
        try {
            TrueorFale = true;

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException();
        }
        if (TrueorFale) {

            tmp = String.valueOf(number.charAt(0) + number.charAt(1));
            if (number.charAt(0) == 0) {
                this.number = number;
            } else if ((tmp.equals("00") && number.charAt(2) != 0)) {
                this.number = number;
            } else if (tmp.charAt(1) != 0 && tmp.charAt(0) == '+') {
                this.number = number;
            } else {
                throw new IllegalArgumentException();
            }
        }
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Phonebookentry that = (Phonebookentry) o;
        return Objects.equals(number, that.number)
    }

    @Override
    public int hashCode() {
        return Objects.hash(number, name, TrueorFale);
    }
}