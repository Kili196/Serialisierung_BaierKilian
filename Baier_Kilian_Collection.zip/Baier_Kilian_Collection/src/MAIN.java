/**
 * Created: 18.10.2021
 *
 * @author Kilian Baier (20190608)
 */
public class MAIN {
    public static void main(String[] args) {


        String str = "+1123";
                try {
                    Double.parseDouble(str);
                    System.out.println("It is numerical string");
                }catch(NumberFormatException e) {
                    System.out.println("It is not numerical string");
                }
            }
    }
