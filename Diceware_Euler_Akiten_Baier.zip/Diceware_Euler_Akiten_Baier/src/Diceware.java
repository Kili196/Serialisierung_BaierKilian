import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * Created: 29.11.2021
 *
 * @author Kilian Baier (20190608)
 */
public class Diceware {

    private static NavigableMap<String, String> levels = new TreeMap<>();

    public static void getDiceWarePaare(String filename) {
        try {
            File file = new File(filename);
            Scanner myReader = new Scanner(file);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] lines = data.split(" ");
                levels.put(lines[0], lines[1]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static String Würfel() {
        Random rand = new Random();
        String newnum = "";
        for (int i = 1; i < 6; i++) {
            int a = rand.nextInt(7);
            if (a == 0) {
                a++;
            }
            newnum = newnum + a;

        }
        return newnum;
    }


    public static String makepw(int vorgänge){
        String pw = "";
        for (int i = 1; i <= vorgänge ; i++) {

            String a = Würfel();

            if(levels.containsKey(a)){
                pw += levels.get(a) + " ";
            }

        }
        return pw;
    }

    public static void main(String[] args) {
        getDiceWarePaare("ressourcen/diceware_german.txt");
        int a = 7;
        System.out.printf("PW: " + makepw(a));



    }



}
