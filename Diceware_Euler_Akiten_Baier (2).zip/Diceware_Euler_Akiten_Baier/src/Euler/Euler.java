package Euler;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created: 29.11.2021
 *
 * @author Kilian Baier (20190608)
 */
public class Euler { ;
    public static List<Integer> numlist = new ArrayList<>();


    public static void addnum(int n){
        int count = 1;
        while (count <= n){
            numlist.add(count);
            count++;
        }
    }



    public static void deletelements(boolean reverse) {
        while (numlist.size() != 1) {
            if (reverse == false) {
                for (int i = numlist.size() - 1; i >= 0; i -= 2) {
                    numlist.set(i, -1);
                    reverse = true;

                }
            } else {
                for (int i = 0; i < numlist.size(); i += 2) {
                    numlist.set(i, -1);
                    reverse = false;
                }
            }

            numlist.removeIf(i -> i == -1);
        }
    }



    public static void main(String[] args) {
        addnum(30);
        deletelements(true);
        System.out.println(numlist);
    }




}
