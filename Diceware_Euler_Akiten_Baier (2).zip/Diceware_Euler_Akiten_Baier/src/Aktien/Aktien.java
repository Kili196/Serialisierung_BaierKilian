package Aktien;

import java.io.File;
import java.util.Scanner;

/**
 * Created: 06.12.2021
 *
 * @author Kilian Baier (20190608)
 */
public class Aktien {


    public static void getDiceWarePaare(String filename) {
        try {
            File file = new File(filename);
            Scanner myReader = new Scanner(file);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] lines = data.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
