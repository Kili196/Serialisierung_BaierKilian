import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Collection;
import java.util.Date;
import java.util.Objects;

/**
 * Created: 13.12.2021
 *
 * @author Kilian Baier (20190608)
 */
public class Schueler implements Comparable<Schueler> {


    private String klasse;
    private String name;
    private String vorname;
    private char geschlecht;
    private LocalDate geboren;
    private String religion;

    public Schueler(String klasse, String name, String vorname, char geschlecht, LocalDate geboren, String religion) {
        this.klasse = klasse;
        this.name = name;
        this.vorname = vorname;
        this.geschlecht = geschlecht;
        this.geboren = geboren;
        this.religion = religion;
    }

    public static Schueler makeSchueler(String Schueler) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.uuuu").withResolverStyle(ResolverStyle.STRICT);
        String[] test = Schueler.split(";");
        System.out.println(test[4]);
        return new Schueler(test[0], test[1], test[2], test[3].charAt(0), LocalDate.parse(test[4], formatter), test[5]);
    }

    public Schueler() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Schueler schueler = (Schueler) o;
        return geschlecht == schueler.geschlecht && Objects.equals(klasse, schueler.klasse) && Objects.equals(name, schueler.name) && Objects.equals(vorname, schueler.vorname) && Objects.equals(geboren, schueler.geboren) && Objects.equals(religion, schueler.religion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(klasse, name, vorname, geschlecht, geboren, religion);
    }

    @Override
    public int compareTo(Schueler o) {
        if (klasse.equals(o.klasse)) {
            if (name.equals(o.name)) {
                if (vorname.equals(o.vorname)) {

                    return vorname.compareTo(o.vorname);
                }
                return name.compareTo(o.name);
            }
            return klasse.compareTo(o.klasse);
        } else {
            return geboren.compareTo(o.geboren);
        }

    }


    public String getKlasse() {
        return klasse;
    }

    public String getName() {
        return name;
    }

    public String getVorname() {
        return vorname;
    }

    public char getGeschlecht() {
        return geschlecht;
    }

    public LocalDate getGeboren() {
        return geboren;
    }

    public String getReligion() {
        return religion;
    }

    public int getAge(LocalDate date) {
        Period period = geboren.until(date);
        int years = period.getYears();
        if (date.isBefore(geboren)) {
            throw new IllegalArgumentException("Student not born yet" + date);
        } else {
            return years;
        }
    }
}
