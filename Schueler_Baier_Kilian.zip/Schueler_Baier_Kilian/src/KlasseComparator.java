import java.util.Comparator;

/**
 * Created: 20.12.2021
 *
 * @author Kilian Baier (20190608)
 */
public class KlasseComparator implements Comparator<Schueler> {
    @Override
    public int compare(Schueler o1, Schueler o2) {
        if(o1.getKlasse().equals(o1.getKlasse())){
            return o1.getKlasse().compareTo(o2.getKlasse());
        }
        if(o1.getName().equals(o2.getName())){
            return o1.getName().compareTo(o2.getName());
        }
        else{
            return  o1.getVorname().compareTo(o2.getVorname());
        }
    }


}
