import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.*;

/**
 * Created: 13.12.2021
 *
 * @author Kilian Baier (20190608)
 */
public class SchuelerVerwaltung extends Schueler {
    public Collection<Schueler> schuelerCollection = new ArrayList<>();

    public SchuelerVerwaltung(String filename) throws FileNotFoundException {
        super();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.uuuu").withResolverStyle(ResolverStyle.STRICT);
        File file = new File(filename);
        Scanner myReader = new Scanner(file);
        myReader.nextLine();
        while (myReader.hasNextLine()) {
            {
                String data = myReader.nextLine();
                String[] tmp = data.split(";");

                if (!tmp[0].isBlank()) {
                    String klasse = tmp[0];
                    String Nachname = tmp[1];
                    String Vorname = tmp[2];
                    char Geschlecht = tmp[3].charAt(0);
                    LocalDate Geburtstag = LocalDate.parse(tmp[4], formatter);
                    String religion = tmp[5];
                    Schueler s1 = new Schueler(klasse, Nachname, Vorname, Geschlecht, Geburtstag, religion);
                    schuelerCollection.add(s1);
                }
            }
        }
    }

    public Set<Schueler> getSchuelerFromKlasse(String klasse) {
        Set<Schueler> schueler = new HashSet<>();
        for (Schueler i : schuelerCollection) {
            if (Objects.equals(i.getKlasse(), klasse)) {
                schueler.add((i));
            }
        }
        return schueler;
    }

    public Set<Schueler> getAllWith(char geschlecht) {
        List<Schueler> schueler = new ArrayList<>();
        for (Schueler i : schuelerCollection) {
            if (Objects.equals(i.getGeschlecht(), geschlecht)) {
                schueler.add(i);
            }
        }
        Collections.sort(schueler, new KlasseComparator());
        Set<Schueler> schuelerset = new HashSet<>(schueler);


        return schuelerset;
    }

    public Map<String, Map<String, List<String>>> getReligionsZugehoerigkeit() {
        Map<String, HashMap> ReligionsMap = new HashMap<>();
        Map<String, ArrayList> Religionwithmap = new HashMap<>();

        for (Schueler i : schuelerCollection) {
            if (ReligionsMap.get(i.getReligion()) == null) {

            }

        }
        return null;
    }

    public Map<String, Integer> getKlassenAnzahl() {
        Map<String, Integer> klassenmap = new HashMap<>();
        for (Schueler i : schuelerCollection) {
            if (!klassenmap.containsKey(i.getKlasse())) {
                klassenmap.put(i.getKlasse(), 1);
            } else {
                klassenmap.put(i.getKlasse(), klassenmap.get(i.getKlasse()) + 1);
            }
        }
        return klassenmap;
    }

    public Set<Schueler> containsName(String name, boolean komplett) {
        Set<Schueler> schuelerset = new HashSet<>();
        if (!komplett) {
            for (Schueler i : schuelerCollection) {
                if (name.contains(i.getName())) {
                    schuelerset.add(i);
                }
            }
        } else {
            for (Schueler i : schuelerCollection) {
                if (name.equals(i.getName())) {
                    schuelerset.add(i);
                }
            }
        }
        return schuelerset;
    }

    public Set<Schueler> getGeborenBis(LocalDate datum, boolean vorNach) {
        Set<Schueler> Schuelerset = new HashSet<>();
        if (vorNach) {
            for (Schueler i : schuelerCollection) {
                if (i.getGeboren().isBefore(datum) || i.getGeboren().equals(datum)) {
                    Schuelerset.add(i);
                }
            }
        } else {
            for (Schueler i : schuelerCollection) {
                if (i.getGeboren().isAfter(datum) || i.getGeboren().equals(datum)) {
                    Schuelerset.add(i);
                }
            }
        }
        return Schuelerset;
    }

    public Map<LocalDate, Set<String>> getGeburtstagsListe(int jahr) {
        return null;
    }

    public Map<LocalDate, Set<String>> getGeburtstagsListe() {
        return null;
    }


}


