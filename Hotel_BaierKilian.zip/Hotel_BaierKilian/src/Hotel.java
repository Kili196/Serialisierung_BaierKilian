import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class Hotel{
    static long OFFSET = 0;
    String name;
    String Location;
    int size;
    boolean smoking;
    int rate;
    LocalDate date;
    String owner;


    public Hotel(String name, String location, int size, boolean smoking, int rate, LocalDate date, String owner){
        this.name = name;
        this.Location = location;
        this.size = size;
        this.smoking = smoking;
        this.rate = rate;
        this.date = date;
        this.owner = owner;
    }

    public Hotel(byte[] data, Map<String, Short> columns) {
    }


    public static Map<String, Short> readColumns(String filename) throws IOException {
        Map<String, Short> retmap = new LinkedHashMap<>();
        RandomAccessFile raf = new RandomAccessFile("ressources/" + filename, "r");
        short namelenght;
        raf.skipBytes(8);
        short collumanzahl = raf.readShort();
        for (int i = 0; i < collumanzahl; i++) {
            namelenght = raf.readShort();
            byte[] b = new byte[namelenght];
            raf.readFully(b);
            String name = new String(b, StandardCharsets.UTF_8);
            retmap.put(name, raf.readShort());
        }
        OFFSET = raf.getFilePointer();

        return retmap;
    }

    public static int getStartingOffset(String filename) throws IOException {
        readColumns(filename);
        return (int) OFFSET;
    }

    public static Set<Hotel> readHotels(String filename) throws IOException{
        return null;
    }
}